package com.capgemini.jpa.presentation;

import java.util.GregorianCalendar;
import java.util.Scanner;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.exception.EmployeeException;
import com.capgemini.jpa.service.EmployeeServiceImpl;
import com.capgemini.jpa.service.IEmployeeService;

public class EmployeeTester {
	private static IEmployeeService employeeService=
								new EmployeeServiceImpl();
	
	public static void main(String[] args) {
		int empid;
		while(true)
		{
			System.out.println("1.ADD Employee");
			System.out.println("2.DELETE Employee");
			System.out.println("3.UPDATE Employee ");
			System.out.println("4.GET Employeedetails");
			System.out.println("5.Get all Employee details");
	    	System.out.println("6.Exit");
	    	Scanner sc=new Scanner(System.in);
	    	int choice;
	    	choice=sc.nextInt();
	    	switch(choice)
	    	{
	    	case 1:
	    		Employee employee=
	 		   new Employee(7000,"Aakanksha",new GregorianCalendar(2016,10,15),"Developer",65750.0,10);
	    		addNewEmployee(employee);
	    		break;
	    	case 3:
	    		Employee employee1=
		 		   new Employee(7000,"Jones",new GregorianCalendar(2016,10,15),"Developer",65750.0,10);
	    		updateEmployee(employee1);
	    		break;
	    	case 2:
	    		System.out.println("enter employee id");
	    		empid=sc.nextInt();
	    		deleteEmployee(empid);
	    		break;
	    	case 4:
	   
	    		System.out.println("enter employee id");
	    		empid=sc.nextInt();
	    		getEmployeeDetails(empid);
	    		break;
	}
		}
	}
	private static void getEmployeeDetails(int empid) {
		try {
			employeeService.getEmployeeDetails(empid);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		
		
	}

	private static void deleteEmployee(int empid) {
		try {
			employeeService.deleteEmployee(empid);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		
	}

	private static void updateEmployee(Employee employee1) {
		try {
			employeeService.updateEmployee(employee1);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		
	}

	private static void addNewEmployee(Employee employee) {
		try {
			employeeService.addNewEmployee(employee);
		} catch (EmployeeException e) {			
			e.printStackTrace();
		}
		
	}

}
