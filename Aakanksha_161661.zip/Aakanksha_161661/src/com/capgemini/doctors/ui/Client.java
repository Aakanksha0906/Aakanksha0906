package com.capgemini.doctors.ui;

import java.util.Scanner;



import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.service.ServiceImp;


public class Client {
	
	static ServiceImp s=new ServiceImp();//OBJECT CREATED
	  
	 public static void main(String[]args)
	    {    
		 String patientName;
		 String phoneNumber;
	     String email;
		 String gender;int n;
		 int age;String problemName;
		  Scanner sw =new Scanner(System.in);//to input value from keyboard
		  while(true) {

			  System.out.println("WELCOME");
				System.out.println("*******************************");
				System.out.println("-------------------------------");
				System.out.println("********************************");
				System.out.println("MENU");
				System.out.println("1.BOOK DOCTOR APPOINTMENT");
				System.out.println("2.VIEW DOCTOR APPOINTMENT");
				System.out.println("7.EXIT");
				System.out.println("*******************************");
				System.out.println("-------------------------------");
				System.out.println("********************************");
				
		        n=sw.nextInt();
		      
		        
		        switch(n){
		        
	            case 1 :
	            	DoctorAppointment d=new DoctorAppointment();//adding the object
	            	int appointmentId=(int)((Math.random()*900000)+100000);
	            	
	                    System.out.println("Enter the patientName");//ENTERINIG THE PATIENT DETAILS
	                    patientName=sw.next();
	                    	                      
	                    System.out.println("Enter the Phonenumber");
	                    phoneNumber=sw.next();
	                    
	                    System.out.println("Enter the email");
	                    email=sw.next();
	                    
	                    System.out.println("Enter the Age");
	                    age=sw.nextInt();
	                    
	                    System.out.println("Enter the gender");
	                    gender=sw.next();
	                    
	                    System.out.println("Enter the problemName");
	                    problemName=sw.next();
	                    d.setAppointmentId(appointmentId);
	                    d.setPatientName(patientName);
	                    d.setPhoneNumber( phoneNumber);
	                    d.setEmail(email);
	                    d.setAge(age);
	                    d.setGender(gender);
	                    d.setProblemName(problemName);
	                  DoctorAppointment b =  s.BookDoctorAppointment(d);
	                if(b==null){
	                	System.out.println("APPOINTMENT REGISTRATION FAILED");
	                  }else{
	                    System.out.println("APPOINTMENT REGISTERED SUCCESSFULLY,id is" + b.getAppointmentId());//REGISTRATION DONE
	                  
	                
		        
	                  }  
	                  
	                   	 
	                    
	                    
	            case 2 :
	            	
	            	System.out.println("View Doctor Appointment");
	            	System.out.println("Dr.Brijesh  - Heart");
	            	System.out.println("Dr.Shrada  - Gynecology");
	            	System.out.println("Dr.Heen khan -Diabetics");
	            	System.out.println("Dr.paras mal  - Ent");
	            	
	            	
	            	
	                    break;

		        case 3: System.exit(0);
          default: 
                  System.out.println("wrong choice");
                  break;
	    }
	   
	    
	
        
}
	    }
}

	

