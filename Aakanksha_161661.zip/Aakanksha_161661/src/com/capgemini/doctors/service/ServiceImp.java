package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DaoImp;

public class ServiceImp implements DoctorAppointmentService {
	 DaoImp d2=new DaoImp();
	
	
	public DoctorAppointment BookDoctorAppointment(DoctorAppointment d) {
		// TODO Auto-generated method stub
		return d2.BookDoctorAppointment(d) ;
	}
   


	
	@Override
	public boolean viewAppointmentDetails() {
		// TODO Auto-generated method stub
		return d2.viewAppointmentDetails();
	}


	
   
}
