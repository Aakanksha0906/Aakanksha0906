package com.capgemini.doctors.service;

import com.capgemini.doctors.bean.DoctorAppointment;

public interface DoctorAppointmentService {
	public interface ServiceInt {
		public DoctorAppointment BookDoctorAppointment(DoctorAppointment d);
		public boolean viewAppointmentDetails();
		

}

	boolean viewAppointmentDetails();

}
