package com.capgemini.doctors.Exception;

import com.capgemini.doctors.bean.DoctorAppointment;

public class Exception extends DoctorAppointment {
	
		public void DoctorNotFound(String d)
		{
			
		}

	}



