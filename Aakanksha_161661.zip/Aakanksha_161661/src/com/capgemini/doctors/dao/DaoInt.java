package com.capgemini.doctors.dao;

import com.capgemini.doctors.bean.DoctorAppointment;

public interface DaoInt {
	public DoctorAppointment BookDoctorAppointment(DoctorAppointment d);
	public boolean viewAppointmentDetails();
	

}
