package com.capgemini.doctors.dao;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;

public class DaoImpTest {
	DoctorAppointment d=newDoctorAppointmentImp();

	@Before
	public void setUp() throws Exception {
		d=newDoctorAppointmentImp();
	}

	

	@After
	public void tearDown() throws Exception {
		d=null;
	}

	@Test
	public void test() {
		fail("Not yet implemented");
	}
	private DoctorAppointment newDoctorAppointmentImp() {
		
		// TODO Auto-generated method stub
		DoctorAppointment d=new DoctorAppointment();
		d.setAppointmentId(1234);
	    


		
		return null;
	}

}
