package com.capgemini.doctors.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;

public class DaoImp implements DaoInt {
	 
	 
	  Scanner sc=new Scanner(System.in);
	    Map <Integer,DoctorAppointment> m=new HashMap<Integer,DoctorAppointment>();
	    DoctorAppointment d=new DoctorAppointment();

	 
	    public DoctorAppointment BookDoctorAppointment(DoctorAppointment d) {
	        // TODO Auto-generated method stub
	         m.put(d.getAppointmentId(), d);
	    return m.get(d.getAppointmentId());
	        }



	
	@Override
	public boolean viewAppointmentDetails() {
		// TODO Auto-generated method stub
		return false;
	}

}
