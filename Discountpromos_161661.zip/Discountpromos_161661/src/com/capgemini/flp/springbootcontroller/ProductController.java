package com.capgemini.flp.springbootcontroller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.flp.service.ProductRepo;


@RestController
public class ProductController {
	
	@Autowired
	 ProductRepo repo;
	
	
	
	
	
	
	

}
