package com.capgemini.flp.springbootcontroller;

public class SpringBootDemoApplication {
	

}
