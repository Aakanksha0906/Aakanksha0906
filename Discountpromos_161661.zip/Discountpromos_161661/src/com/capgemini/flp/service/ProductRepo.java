package com.capgemini.flp.service;

import org.springframework.stereotype.Repository;

@Repository
public interface ProductRepo {
	
	
	

}
