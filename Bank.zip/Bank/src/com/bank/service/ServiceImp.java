package com.bank.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.bank.bean.Customer;
import com.bank.dao.DaoImpl;

public  class ServiceImp implements ServiceInterface  {
	
	DaoImpl dao=new DaoImpl();
	
	public boolean validatePhno(String mobileno)
	{
		boolean flag = false;
	    Pattern pattern = Pattern.compile("^(0/91)?[7-9][0-9]{9}");
	    Matcher matcher = pattern.matcher(mobileno);
	    if(matcher.matches())
	    {
	        flag=true;
	    }
		return flag;	
	}
	public boolean validateName(String name)
	{
		boolean flag = false;
		if(name.matches("^[A-Za-z\\s]+$"))
		{
			flag = true;
		}
		return flag;	
	}
	public boolean validateAge(int age)
	{
		boolean flag = false;
		if(age>18 && age<100)
		{
			flag = true;
		}
		return flag;	
	}
	public boolean validatePan(String panno)
	{
		boolean flag = false;
		if(panno.matches("^[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}"))
		{
			flag = true;
		}
		return flag;	
	}
	 public boolean validateMail(String email)
	 {
		 boolean flag=false;
		 if(email.matches("^[_a-zA-Z0-9-]+(\\.[_a-zA-Z0-9-]+)*@[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)*([a-zA-Z]{2,3})"))
		 {
			 flag=true;
		 }
		 return flag;
		 
	 }
	
public boolean validateDate(Customer c) {
		boolean flag=false;
		Pattern p=Pattern.compile("A-Za-z");
		Matcher m=p.matcher(c.getName());
		 boolean a=m.matches();
		 Pattern p1=Pattern.compile("[1-9][0-9]{9}");
			Matcher m1=p1.matcher(c.getPhoneNumber());
			 boolean b =m1.matches();
			Pattern p3=Pattern.compile("hyd");
				Matcher m3=p3.matcher(c.getAddress());
				 boolean d=m3.matches();
		// TODO Auto-generated method stub
		 if(a&&b&&d){
			  flag=true;
		 }
		 return flag;
	}
public Customer displayCust(int accNumber) {
	return dao.displayCust(accNumber);
}




	public int withDraw(Customer c,int withdraw) {
		// TODO Auto-generated method stub
		if(c.getCurrBal()-withdraw>500)
		{
			withdraw=(int) (c.getCurrBal()-withdraw);
			
		// TODO Auto-generated method stub
			
		
	
		}
	
	return dao.withDraw(c,withdraw);
	}

	@Override
	public boolean addCustomer(Customer c) {
		// TODO Auto-generated method stub
		return dao.addCustomer(c);
	}





	public int deposit(Customer c,int deposit) {
		// TODO Auto-generated method stub
		if(deposit>=100)
		{
			deposit=(int) (c.getCurrBal()+deposit);
			
		}
		
			return dao.deposit(c,deposit);
		}
		
		
	
	





	public boolean validAccountNo(String email,int accNumber,int pin)
	{
	return	dao.validAccountNo(email,accNumber,pin);
		// TODO Auto-generated method stub
		
	}
	public boolean validateAmount(int withdraw)
	{
		return dao.validateAmount(withdraw);
	}









	@Override
	public int showBalance(int accNumber1) {
		// TODO Auto-generated method stub
		return dao.showBalance(accNumber1);
	}





	public boolean verifyAcc(String email4, int accNumber4) {
		// TODO Auto-generated method stub
		return dao.verifyAcc(email4, accNumber4);
	}
	@Override
	public boolean fundTransfer(String email3, int accNumber3, int pin3, Customer a, Customer b, String email4,
			int accNumber4, int amount) {
		// TODO Auto-generated method stub
		return fundTransfer(email3,accNumber3,pin3,a,b,email4,accNumber4,amount);
	}



}