package com.capg.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.Student.Student;
import com.capg.dao.DaoImp;

public class ServiceImp implements IService {
	DaoImp dao=new DaoImp();

	public boolean validateName(String name2) {
		// TODO Auto-generated method stub
	
		    boolean flag=false;
		    Pattern name=Pattern.compile("^[A-Z][A-za-z,\\s]+");
		    Matcher nameMatch=name.matcher(name2);
		    if(nameMatch.matches())
		    {
		        flag=true;
		    }
		    else
		    {
		        flag=false;
		    }
		    return flag;
		    }
	

	public boolean validateAge(int age) {
		// TODO Auto-generated method stub
		 {
			    boolean flag=false;
			    if(age>0)
			    {
			        flag=true;
			    }
			    else
			    {
			        flag=false;
			    }
			    return flag;
			    }
	}

	public boolean validateschoolname(String schoolname) {
		// TODO Auto-generated method stub
		 boolean flag=false;
		    Pattern name=Pattern.compile("^[A-Z][A-za-z,\\s]+");
		    Matcher nameMatch=name.matcher(schoolname);
		    if(nameMatch.matches())
		    {
		        flag=true;
		    }
		    else
		    {
		        flag=false;
		    }
		    return flag;
		    }
	

	public boolean validatesscmark(int sscmark) {
		// TODO Auto-generated method stub
		 {
			    boolean flag=false;
			    if(sscmark>0)
			    {
			        flag=true;
			    }
			    else
			    {
			        flag=false;
			    }
			    return flag;
			    }
	}

	public boolean validatehscmark(int hscmark) {
		// TODO Auto-generated method stub
		{
		    boolean flag=false;
		    if(hscmark>0)
		    {
		        flag=true;
		    }
		    else
		    {
		        flag=false;
		    }
		    return flag;
		    }
		
	}

	public Integer addStudent(Student student) {
		// TODO Auto-generated method stub
		return dao.addStudent(student);
		
	}
	public boolean validStudent(int id) {
		
		// TODO Auto-generated method stub
		return dao.validStudent(id);
	}
		
		
		

		


		public Student displayStudent(int studentId) {
			// TODO Auto-generated method stub
			return dao.displayStudent(studentId);
		}


		

	
	
	

}
