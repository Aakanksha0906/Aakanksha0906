package com.capg.service;

import com.capg.Student.Student;


public interface IService {
	
	public Integer addStudent(Student student);
	public Student displayStudent(int userid);

}
