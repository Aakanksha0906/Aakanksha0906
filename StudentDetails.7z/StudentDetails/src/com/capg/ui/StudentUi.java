package com.capg.ui;

import java.util.Scanner;

import com.capg.Student.Student;

import com.capg.service.ServiceImp;

public class StudentUi {
	
	static Integer studentId=1000;
	static ServiceImp service=new ServiceImp();


	public static void main(String[] args)   {
		try {
		
		int age,sscmark,hscmark;
		int choice;
		String name,schoolname;
		boolean b,condition;
		Scanner sc = new Scanner(System.in);
	    Scanner sc2 = new Scanner(System.in);
	do {
		
		//printing menu
		System.out.println("\nStudent Counselling\n");
	    System.out.println("\nMENU\n");
	    System.out.println("1.StudentDetails");
	    System.out.println("2.Display Student ");
	    
	    
	    System.out.println("\nEnter Your Choice");
	    choice = sc.nextInt();
	    condition=true;
	        
	        switch (choice) {
	        
	        case 1:

	        	//getting name input from user
	            
	            do{
	                System.out.println("\nEnter the User Name [with Initial as capital]");
	                name = sc2.nextLine();
	                b=service.validateName(name);
	                if(b==true)
	                {
	                    continue;
	                }
	                else
	                {
	                    System.out.println("\n Name Invalid");
	                }
	                }while(b==false);
	            
	            
	            
	          //getting age input from user
	            
	            do{
	                System.out.println("Enter the  Age [Above 0]");
	                age=sc.nextInt();
	                b=service.validateAge(age);
	                if(b==true)
	                {
	                    continue;
	                }
	                else
	                {
	                    System.out.println("\nAge Invalid");
	                }
	                }while(b==false);
	            
	            
	            
	            
	         
	            
	            
	          //getting phone number input from user
	            do{
	                System.out.println("Enter SchoolName");
	                schoolname = sc2.nextLine();
	                b=service.validateschoolname(schoolname);
	                if(b==true)
	                {
	                    continue;
	                }
	                else
	                {
	                    System.out.println("Schoolname is invalid");
	                }
	                }while(b==false);
	            
	            do{
	                System.out.println("Enter the  SSC MARK [Above 0]");
	                sscmark=sc.nextInt();
	                b=service.validatesscmark(sscmark);
	                if(b==true)
	                {
	                    continue;
	                }
	                else
	                {
	                    System.out.println("\nSSCMark Invalid");
	                }
	                }while(b==false);
	            
	            do{
	                System.out.println("Enter the  HSC MARK [Above 0]");
	                hscmark=sc.nextInt();
	                b=service.validatehscmark(age);
	                if(b==true)
	                {
	                    continue;
	                }
	                else
	                {
	                    System.out.println("\nHSC MARK Invalid");
	                }
	                }while(b==false);
	            
	            
	            Student student =new Student();
	            
	            student.setName(name);
	            student.setAge(age);
	            student.setSchoolname(schoolname);
	            student.setSscmark(sscmark);
	            student.setHscmark(hscmark);
	            student.setStudentid(studentId);
	          

	            
		          Integer c =  service.addStudent(student);
		          studentId++;
	                if(c==0){
	                	System.out.println("STUDENT REGISTRATION FAILED");
	                	break;
	                  }else{
	                    System.out.println("STUDENT REGISTERED SUCCESSFULLY,id is" + c);//REGISTRATION DONE
	                  
	                    break;
	                  }
	                
	        
	                
	                
	                
	        case 2:
	        	System.out.println("enter id");
				int studentId = sc.nextInt();
				boolean result=service.validStudent(studentId);
				if(result==true){
				Student s=service.displayStudent(studentId);
				System.out.println(s);
				break;
				}
				else{
					
				System.out.println("Invalid id");
				break;
				}
			       
		       default: 
		    	   System.out.println("Wrong Choice");
		    	   break;

		}
		}while(condition);
		sc.close();
		sc2.close();
			}
			//handling exception
			catch(Exception e){
				System.out.println(e);
				
			}
		
		}
	}

	                
	            
	            
	            
	            
	            
	            
	            
	        
	
		
	
	
	        
	
	