package com.capg.Student;

public class Student {
	private String name;
	private int age;
	private String schoolname;
	private int sscmark;
	private int hscmark;
	private Integer studentId;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	public String getSchoolname() {
		return schoolname;
	}
	public void setSchoolname(String schoolname) {
		this.schoolname = schoolname;
	}
	
	public int getSscmark() {
		return sscmark;
	}
	public void setSscmark(int sscmark) {
		this.sscmark = sscmark;
	}
	public int getHscmark() {
		return hscmark;
	}
	public void setHscmark(int hscmark) {
		this.hscmark = hscmark;
	}
	public int getStudentid() {
		return studentId;
	}
	public void setStudentid(Integer studentid) {
		this.studentId = studentid;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + ", schoolname="
				+ schoolname + ", sscmark=" + sscmark + ", hscmark=" + hscmark
				+ ", Studentid=" + studentId + "]";
	}
	
}
