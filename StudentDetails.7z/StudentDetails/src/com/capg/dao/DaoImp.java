package com.capg.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capg.Student.Student;
                                                                                                      



public class DaoImp implements IDao {
	Scanner sc=new Scanner(System.in);
    Map <Integer,Student> m=new HashMap<Integer,Student>();
    Student student=new Student();

 
    public Integer addStudent(Student student)  {
        // TODO Auto-generated method stub
    	
         m.put(student.getStudentid(), student);
         return student.getStudentid();
        }
    
    
    
    
    
       public Boolean validStudent(int studentId) {
   		Boolean us=false;
   		
   	
   		for(Student user:m.values())
   		{
   			if(user.getStudentid()==studentId)
   				us=true;
   		}
   			
   			return us;
   		}





	









	@Override
	public Student displayStudent(int studentId) {
		// TODO Auto-generated method stub
		Student us=null;
		
		
		for(Student user:m.values())
		{
			if(user.getStudentid()==studentId)
				us=user;
		}
			
			return us;
		}
	}





	




	


