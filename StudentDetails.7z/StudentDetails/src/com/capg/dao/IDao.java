package com.capg.dao;

import com.capg.Student.Student;

public interface IDao {
	public Integer addStudent(Student student);

	public Student displayStudent(int userid);



}
