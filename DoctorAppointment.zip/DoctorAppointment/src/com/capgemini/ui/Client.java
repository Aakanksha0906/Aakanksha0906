package com.capgemini.ui;

import java.time.LocalDate;
import java.util.Scanner;

import com.capemini.bean.DoctorAppointment;


import com.capgemini.doctors.exception.DoctorAppointmentException;

import com.capgemini.service.DoctorAppointmentService;

public class Client {
	
	static int appointmentid=1000;       //
	static  DoctorAppointmentService service=new DoctorAppointmentService();  //

	public static void main(String[] args) throws DoctorAppointmentException  {
		try {
		
			 int appointmentId;
			 String patientName,phoneNumber,email,gender;
			 String appointmentDate;
			 int age,choice;
			 String problemName = null,doctorName = null,appointmentStatus = null;
			
		     boolean b,condition;
		     Scanner sc = new Scanner(System.in);
	          Scanner sc2 = new Scanner(System.in);
	do {
		
		//printing menu
		System.out.println("\nUser Details\n");             //
	    System.out.println("\nMENU\n");
	    System.out.println("1.Book Doctor Appointment");
	    System.out.println("2.View Doctor Appointment ");
	   
	    
	    System.out.println("\nEnter Your Choice");
	    choice = sc.nextInt();
	    condition=true;
	        
	        switch (choice) {

	        case 1:

	        	//getting name input from user
	            
	            do{
	                System.out.println("\nEnter the Patient Name [with Initial as capital]");
	                patientName = sc2.nextLine();
	                b=service.validateName(patientName);
	                if(b==true)
	                {
	                    continue;
	                }
	                else
	                {
	                    System.out.println("\n Name Invalid");
	                }
	                }while(b==false);
	            
	            
	            
	          //getting age input from user
	            
	            do{
	                System.out.println("Enter the  Age [Above 0]");
	                age=sc.nextInt();
	                b=service.validateAge(age);
	                if(b==true)
	                {
	                    continue;
	                }
	                else
	                {
	                    System.out.println("\nAge Invalid");
	                }
	                }while(b==false);
	            
	            
	            
	            
	         
	            
	            
	          //getting phone number input from user
	            do{
	                System.out.println("Enter User Mobile number [10 digits]");
	                phoneNumber = sc.next();
	                b=service.validatephoneNumber(phoneNumber);
	                if(b==true)
	                {
	                    continue;
	                }
	                else
	                {
	                    System.out.println("Phone Number invalid");
	                }
	                }while(b==false);
	            do{
	                System.out.println("Enter Patient e-mail Id");
	                email=sc.next();
	                b=service.validateemail(email);
	                if(b==true)
	                {
	                    continue;
	                }
	                else
	                {
	                    System.out.println("\nInvalid e-mail Id");
	                }
	                }while(b==false);
	            do{
	                System.out.println("Enter Patient Problem ");
	                problemName=sc.next();
	                b=service.validateProblem(problemName);
	                if(b==true)
	                {
	                    continue;
	                }
	                else
	                {
	                    System.out.println("\naadhaar invalid");
	                }
	                }while(b==false);
	            
	            appointmentStatus=service.appointmentStatus(problemName);
	            doctorName=service.doctorName(problemName);
	            appointmentDate="2nd November,2018";
	            
	            
	            
	         
	            
	            
	            DoctorAppointment doctorAppointment=  new DoctorAppointment();       // create bean object 
	            
	            
	            //setting the user input values to the bean class object
	            doctorAppointment.setPatientName(patientName);     //set the details
	            doctorAppointment.setAge(age);
	            doctorAppointment.setPhoneNumber(phoneNumber);
	            doctorAppointment.setAppointmentStatus(appointmentStatus);
	            doctorAppointment.setDoctorName(doctorName);
	            doctorAppointment.setProblemName(problemName);
	            
	            doctorAppointment.setAppointmentId(appointmentid);     
	            appointmentid++;
	            
	          Integer c =  service.addUser(doctorAppointment);    //up the bean object
                if(c==null){
                	System.out.println("APPOINTMENT REGISTRATION FAILED");
                  }else{
                    System.out.println("APPOINTMENT REGISTERED SUCCESSFULLY,id is" + c);//REGISTRATION DONE
                  
	            // c consists of total details stored in integer c (up)
	         

	            break;
                  }
	        case 2:
	        	System.out.println("enter appointmentid");
				int appointmentid = sc.nextInt();
				boolean result=service.validDoctorAppointment(appointmentid);//id
				if(result==true){
			   DoctorAppointment u=service.displayDoctorAppointment(appointmentid);//creating some object u with bean class
				System.out.println(u);
				break;
				}
				else{
					
				System.out.println("Invalid id");
				break;
				}
  default: 
	   System.out.println("Wrong Choice");
	   break;

}
}while(condition);
sc.close();
sc2.close();
}
//handling exception
catch(Exception e){
	System.out.println(e);
	throw new DoctorAppointmentException();
}

}
}

