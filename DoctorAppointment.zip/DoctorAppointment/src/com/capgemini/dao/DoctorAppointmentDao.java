package com.capgemini.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capemini.bean.DoctorAppointment;


public class DoctorAppointmentDao {
	 Scanner sc=new Scanner(System.in);
	    Map <Integer,DoctorAppointment> m=new HashMap<Integer,DoctorAppointment>();
	    DoctorAppointment doctorAppointment=new DoctorAppointment(); //creating bean object it should be same

	 
	    public Integer addUser(DoctorAppointment doctorAppointment)  {// bean ,bean obj
	        // TODO Auto-generated method stub
	    	
	         m.put(doctorAppointment.getAppointmentId(), doctorAppointment);  //beanobj.getid,beanobj
	         return doctorAppointment.getAppointmentId();
	        }
	    
	    
	    
	    
	    
	       public Boolean validDoctorAppointment(int appointmentid) {
	   		Boolean us=false;                  //creating the obj
	   		
	   	
	   		for(DoctorAppointment doctorAppointment:m.values())  //bean beanobj:m values
	   		{
	   			if(doctorAppointment.getAppointmentId()==appointmentid)  // bean.getid()=id
	   				us=true;
	   		}
	   			
	   			return us;                         //return the obj
	   		}
	   		

	
	       
	       
	        
    public DoctorAppointment displayDoctorAppointment(int appointmentid ) {
    	DoctorAppointment us=null;
		
	
		for(DoctorAppointment doctorAppointment:m.values())
		{
			if(doctorAppointment.getAppointmentId()==appointmentid)
				us=doctorAppointment;
		}
			
			return us;
		}
		
		
		

}



