package com.capgemini.dao;

import com.capemini.bean.DoctorAppointment;

public interface IDoctorAppointmentDao {
	public Integer addUser(DoctorAppointment doctorAppointment);
	public boolean validatephoneNumber(String phoneNumber);
	public boolean validateName(String patientName);
	public boolean validateAge(int age) ;
	

}
