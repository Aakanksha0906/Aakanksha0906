package com.capgemini.service;

import com.capemini.bean.DoctorAppointment;

public interface IDoctorAppointmentService {
	public Integer addUser(DoctorAppointment doctorAppointment);
	public boolean validatephoneNumber(String phoneNumber);
	public boolean validateName(String patientName);
	public boolean validateAge(int age) ;
	
	
}
