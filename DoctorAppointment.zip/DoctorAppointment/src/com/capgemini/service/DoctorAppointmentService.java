package com.capgemini.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capemini.bean.DoctorAppointment;
import com.capgemini.dao.DoctorAppointmentDao;

public class DoctorAppointmentService implements IDoctorAppointmentService {
	DoctorAppointmentDao dao=new DoctorAppointmentDao();

	public boolean validateName(String patientName) {
		// TODO Auto-generated method stub
		
	    {
	    boolean flag=false;
	    Pattern name=Pattern.compile("^[A-Z][A-za-z,\\s]+");
	    Matcher nameMatch=name.matcher(patientName);
	    if(nameMatch.matches())
	    {
	        flag=true;
	    }
	    else
	    {
	        flag=false;
	    }
	    return flag;
	    }
	    
	}

	public boolean validateAge(int age) {
		// TODO Auto-generated method stub
		{
		    boolean flag=false;
		    if(age>0)
		    {
		        flag=true;
		    }
		    else
		    {
		        flag=false;
		    }
		    return flag;
		    }
		    
		    
	}

	public boolean validatephoneNumber(String phoneNumber) {
		// TODO Auto-generated method stub
		boolean flag=false;
	    Pattern number=Pattern.compile("[0-9]{10}");
	    Matcher numMatch=number.matcher(phoneNumber);
	    if(numMatch.matches())
	    {
	        flag=true;
	    }
	    else
	    {
	        flag=false;
	    }
	    return flag;
	    }
	    
	    
			

	public Integer addUser(DoctorAppointment doctorAppointment) {
		// TODO Auto-generated method stub
		return dao.addUser(doctorAppointment);
	}

	public boolean validDoctorAppointment(int appointmentid) {
		// TODO Auto-generated method stub
		return dao.validDoctorAppointment( appointmentid) ;
	}

	public DoctorAppointment displayDoctorAppointment(int appointmentid) {
		// TODO Auto-generated method stub
		return dao.displayDoctorAppointment(appointmentid);
	}

	public boolean validateemail(String email) {
		// TODO Auto-generated method stub
		 boolean flag=false;

		    if(email.endsWith(".com"))
		    {
		        flag=true;
		    }
		    else
		    {
		        flag=false;
		    }
		    return flag;
		    }

			  
	public String appointmentStatus(String problemName) {
		// TODO Auto-generated method stub
		{
		    String pblm1="Heart",pblm2="Gynecology",pblm3="Diabetes",pblm4="ENT",pblm5="Bone",pblm6="Dermatology";
		    String flag="DISAPPROVED";
		    if(pblm1.equalsIgnoreCase(problemName)||pblm2.equalsIgnoreCase(problemName)||pblm3.equalsIgnoreCase(problemName)||
		    		pblm4.equalsIgnoreCase(problemName)||pblm5.equalsIgnoreCase(problemName)||pblm6.equalsIgnoreCase(problemName))
		    {
		    	flag="APPROVED\n\nAPPOINTMENT DATE AND TIME, ALONG WITH DOCTOR'S PHONE NUMBER WILL BE SHARED SHORTLY";
		    }	
		    return flag;
		    }
	}

	public String doctorName(String problemName) {
		// TODO Auto-generated method stub
		 {
			    String flag=null;
			    String pblm1="Heart",pblm2="Gynecology",pblm3="Diabetes",pblm4="ENT",pblm5="Bone",pblm6="Dermatology"; 
			    if(pblm1.equalsIgnoreCase(problemName))
			    {
			    	
			    	flag="Dr. Brijiesh Kumar";
			    }
			    
			    else if (pblm2.equalsIgnoreCase(problemName))
			    {
			    	flag="Dr. Sharda Singh";
			    }
			    
			    else if(pblm3.equalsIgnoreCase(problemName))
			    {
			    	flag="Dr. Heena Khan";
			    }
			    else if(pblm4.equalsIgnoreCase(problemName))
			    {
			    	flag="Dr. Paras mal";
			    }
			    else if(pblm5.equalsIgnoreCase(problemName))
			    {
			    	flag="Dr. Renuka Kher";
			    }
			    else if(pblm6.equalsIgnoreCase(problemName))
			    {
			    	flag="Dr.Kanika Kapoor";
			    }	
			    return flag;
			    }
		
	}

	public boolean validateProblem(String problemName) {
		// TODO Auto-generated method stub
		  boolean flag=false;
		    Pattern problem=Pattern.compile("[A-za-z,\\s]+");
		    Matcher problemMatch=problem.matcher(problemName);
		    if(problemMatch.matches())
		    {
		        flag=true;
		    }
		    else
		    {
		        flag=false;
		    }
		    return flag;
		    }



	}
	


