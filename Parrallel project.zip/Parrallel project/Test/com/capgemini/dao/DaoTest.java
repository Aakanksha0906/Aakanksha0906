package com.capgemini.dao;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.entity.Bean;
import com.capgemini.exception.BeanNotFound;

public class DaoTest {
	Dao d =new Dao();
	Bean b=null;
	

	@Test
	public void testCreateAccount() {
		b=new Bean();
		b.setAccountNumber(1);
		b.setCurrentBalance(9000);
		b.setMobNumber("9177110567");
		b.setAadhaarNumber("9013496699");
		b.setCustomerid("1234567");
		b.setName("Akki");
		boolean c;
		try {
			c = d.createAccount(b);
			assertTrue("true",c);
		} catch (BeanNotFound e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	/*@Test
	public void testShowbalance() {
		fail("Not yet implemented");
	}*/

	@Test
	public void testDeposit() {
		b=new Bean();
		b.setAccountNumber(1);
		try {
			double test=d.deposit(100.0, b.getAccountNumber());
			assertEquals(100.0, test);
			
		} catch (BeanNotFound e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/*@Test
	public void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testFundTransfer() {
		fail("Not yet implemented");
	}*/

}
