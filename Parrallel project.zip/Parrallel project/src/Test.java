import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNotEquals;

import static org.junit.jupiter.api.Assertions.fail;

import com.capg.bean.Bean;
import com.capg.dao.Dao;



class Test extends Dao{
	Bean b=new Bean();
	Bean a=new Bean();

	@org.junit.jupiter.api.Test
	void testCreateAccount() {
		assertNotEquals(a, b);
	}

	@org.junit.jupiter.api.Test
	void testShowbalance() {
		a.setCurrentBalance(2000);
		assertNotNull(a.getCurrentBalance());
	}

	@org.junit.jupiter.api.Test
	void testDeposit() {
		a.setCurrentBalance(3000);
		b.setCurrentBalance(3000);
		assertNotEquals(a, b);
	}

	@org.junit.jupiter.api.Test
	void testWithdraw() {
		a.setCurrentBalance(3000);
		b.setCurrentBalance(2000);
		double withdraw=a.getCurrentBalance();
		assertNotEquals(a.getCurrentBalance(),b.getCurrentBalance() );
	}

	@org.junit.jupiter.api.Test
	void testFundTransfer() {
		fail("Not yet implemented");
	}

	@org.junit.jupiter.api.Test
	void testPrintTransaction() {
		fail("Not yet implemented");
	}

}
