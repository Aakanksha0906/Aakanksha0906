  package com.capg.ui;
import java.util.Scanner;

import com.capg.bean.Bean;
import com.capg.dao.Dao;
import com.capg.exception.BeanNotFound;
import com.capg.service.Service;

public class Ui {
    static Service s=new Service();
    static Bean b=new Bean();
    Dao d=new Dao();
    
    
    
    public static void main(String[]args)
    {       
        
        
        String name;
        String mobNumber;
        String aadhaarNumber;
        int n;String customerid;

        Scanner sw =new Scanner(System.in);
        
        while(true) {

        System.out.println(" 1.Create accountNumber\n 2.ShowBalance\n 3.Deposited\n 4.WithDraw\n 5.FundTransfer\n 6.Print Transactions");
        System.out.println(" Enter u r choice");
        
        n=sw.nextInt();
        boolean z;
        switch(n){
        
            case 1 :
            
            do {
                        
                    System.out.println("Enter the Name");
                    name=sw.next();
                    z=s.isValidName(name);
                    }while(z==false);
                    
                    
                    do {
                        
                    System.out.println("Enter the Aadhar");
                    aadhaarNumber=sw.next();
                    z=s.isValidaadharNumber(aadhaarNumber);
                    }while(z==false);
                    
                    
                    do {
                        
                    System.out.println("Enter the MobNumber");
                    mobNumber=sw.next();
                    z=s.isValidMobNumber(mobNumber);
                    }while(z==false) ;
                    
                    
                    do {
                        
                    System.out.println("Enter the CustomerId");
                    customerid=sw.next();
                    z=s.isValidCustomerId(customerid);
                    }while(z==false);
                    
                    
                    
                    b.setName(name);
                    b.setAadhaarNumber(aadhaarNumber);
                    b.setMobNumber(mobNumber);
                    b.setCustomerid(customerid);
                    b.getAccountNumber();
                    b.getCustomerid();
                    boolean isValid=s.addBean(b);
                    if(isValid) {
                        Bean add=s.createAccount(b);
                        
                    }else {
                        System.out.println("Not Recorded");
                    }
                    
                    System.out.println(s.createAccount(b));
                    
                    
                    break;
            case 2 :System.out.println("show balance");
                    System.out.println("enter the account number");
                    int accountNumber1 = sw.nextInt();
                    System.out.println("enter the pin");
                    int pin1 = sw.nextInt();
            
                    boolean valid= s.validAccountNumber( accountNumber1, pin1);
                    if (valid) {
                    	
                     int balanceAmount = s.showBalance(accountNumber1);
                        System.out.println("Balance is" + balanceAmount);
                    }else
                        System.out.println("enter valid details");
                        
                        break;
            
            case 3:
                System.out.println("deposit");
                System.out.println("enter the account number");
                int accountNumber2 = sw.nextInt();
                System.out.println("enter the pin");
                int pin2 = sw.nextInt();
                boolean valid1 = s.validAccountNumber( accountNumber2, pin2);
                if (valid1) {
                    System.out.println("enter the amount to be deposit");
                    int deposit = sw.nextInt();
                    int deposit1 = s.deposit(b,deposit);
                    b.setCurrentBalance(deposit);
                    System.out.println("deposited successfully");
                    System.out.println("the deposited amount is" + deposit);
                    System.out.println("Balance is" + deposit);


                } else
                    System.out.println("Enter the valid amount");

                break;
                        
            case 4:     
                    System.out.println(" withdraw ");
                    System.out.println("enter the account number");                                            
                    int accountNumber3 = sw.nextInt();                                                              
                    System.out.println("enter the pin");                                                       
                    int pin3 = sw.nextInt();                                                                    
                    boolean valid2= s.validAccountNumber( accountNumber3, pin3);                             
                    if (valid2) {                                                                               
                    	System.out.println("enter the amount to be withdraw");                                 
                    	int withdraw = sw.nextInt();                                                           
                    	boolean validateAmount = s.validateAmount(withdraw);                             
                    	if (validateAmount) {                                                                  
                                                                                                               
                    		int withdrawresult = s.withDraw(b, withdraw);                             
                    		System.out.println("withdraw successful");                                         
                    		System.out.println("withdrawn amount is"+withdraw);                                
                    		System.out.println(" Remaining balance is :" + withdrawresult);                    
                    	} else                                                                                 
                    		System.out.println("the amount should not be more than available amount");         
                    } else                                                                                     
                    	System.out.println("enter the digits only");                                           
                                                                                                               
                    break;                                                                                     
                                                                                                               
                  
            case 5:
                    System.out.println("Fund transfer");
                    System.out.println("enter the account no of transferer");
                    int accountnumber4=sw.nextInt();
                    System.out.println("enter the pin");                                                       
                    int pin4 = sw.nextInt();                                                                    
                    boolean valid3= s.validAccountNumber( accountnumber4, pin4);                             
                    if (valid3) {  
                    	System.out.println("enter the account no of receiver");
                        int accountnumber5=sw.nextInt();
                        boolean valid4= s.validAccountNumber( accountnumber5); 
                        Bean a= new Bean();
                        if (valid4) {
                        	System.out.println("enter the amount to be withdraw");                                 
                        	int amount = sw.nextInt(); 
                        	boolean fund= s.fundTransfer(b,a,accountnumber4,accountnumber5,pin4,amount);
                        	if(fund){
   							 System.out.println("BALANCE IN YOUR ACCOUNT AFTER TRANSFER IS"+a.getCurrBal());
   								System.out.println("BALANCE IN OTHER ACCOUNT IS"+b.getCurrBal());
   						}else {
   							try
   							{
   									throw new BeanNotFound("SORRRY TRANSACTION FAILED!!!!");
   									
   							}
   							catch(BeanNotFound e)
   							{
   								System.out.println(e.getMessage());
   							}
   							
   						}
   					}
   						else
   						{
   							
   							try
   							{
   									throw new BeanNotFound("ENTER THE VALID DETAILS TO TRANSFER");
   									
   							}
   							catch(BeanNotFound e)
   							{
   								System.out.println(e.getMessage());
   							}
   					
                        }
                    }
                        
                    
                   
                    break;
            case 6:
                    System.out.println("Transaction");
                    s.printTransaction();
                    break;
            case 7: System.exit(0);
            default: 
                    System.out.println("wrong choice");
                    break;
        }
        
            }
        }

}
