package com.capg.bean;

public class Bean {
    String name;
    String mobNumber,aadhaarNumber;
    String customerid ;
     int  accountNumber =(int)((Math.random()*900000)+100000);
     int pin=(int)((Math.random()*100)+1000); 
     
//     public int MinBalance;
//     public int getMinBalance() {
//         return MinBalance;
//     }
     public double CurrentBalance=0;
     public double getCurrentBalance() {
         return CurrentBalance;
     }
    
    
//    public void setMinBalance(int minBalance) {
//        MinBalance = minBalance;
//    }


    public void setCurrentBalance(double currentBalance) {
        CurrentBalance = currentBalance;
    }


    public int getPin() {
    return pin;
}
    public void setPin(int pin) {
    this.pin = pin;
}
    
    public String getCustomerid() {
        return customerid;
    }


    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }


    public int getAccountNumber() {
        return accountNumber;
    }


    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }


    public void setAadhaarNumber(String aadhaarNumber) {
        this.aadhaarNumber = aadhaarNumber;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    

    public  String getMobNumber() {
        return mobNumber;
    }
    public void setMobNumber(String mobNumber) {
        this.mobNumber = mobNumber;
    }
    public String getAadhaarNumber() {
        return aadhaarNumber;
    }
    
    
    @Override
    public String toString() {
        return "Bean [name=" + name + ", mobNumber=" + mobNumber + ", aadhaarNumber=" + aadhaarNumber
                + ", accountNumber=" + accountNumber + ", customerid=" + customerid + ", pin=" + pin + "]";
    }


    public int getCurrBal() {
        // TODO Auto-generated method stub
        return 0;
    }


    public void setCurrBal(int dep) {
        // TODO Auto-generated method stub
        
    }
    
    
    }
    
    
    
    