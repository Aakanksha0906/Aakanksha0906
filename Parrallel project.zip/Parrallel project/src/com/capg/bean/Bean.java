package com.capg.bean;

public class Bean {
  private String name;
  private String mobNumber,aadhaarNumber;
  private String customerid ;
  int accountNumber;
  int pin;

     public double CurrentBalance=0;
     public double getCurrentBalance() {
         return CurrentBalance;
     }
    
   

    public void setCurrentBalance(double currentBalance) {
        CurrentBalance = currentBalance;
    }


    public int getPin() {
    return pin;
}
    public void setPin(int pin) {
    this.pin = pin;
}
    
    public String getCustomerid() {
        return customerid;
    }


    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }


    public int getAccountNumber() {
        return accountNumber;
    }


    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }


    public void setAadhaarNumber(String aadhaarNumber) {
        this.aadhaarNumber = aadhaarNumber;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    

    public  String getMobNumber() {
        return mobNumber;
    }
    public void setMobNumber(String mobNumber) {
        this.mobNumber = mobNumber;
    }
    public String getAadhaarNumber() {
        return aadhaarNumber;
    }
    
    
    @Override
    public String toString() {
        return "Bean [name=" + name + ", mobNumber=" + mobNumber + ", aadhaarNumber=" + aadhaarNumber
                + ", accountNumber=" + accountNumber + ", customerid=" + customerid + ", pin=" + pin + "]";
    }


    
    
    }
    
    
    
    