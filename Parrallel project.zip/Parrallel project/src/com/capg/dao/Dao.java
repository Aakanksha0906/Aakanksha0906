package com.capg.dao;


import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capg.bean.Bean;

public class Dao implements DaoInterface{
    static double balance;
    double deposit,withdraw,fundTransfer;
     
  int  accountNumber=(int)((Math.random()*900000)+100000);
 
  Scanner sc=new Scanner(System.in);
    Map <Integer,Bean> m=new HashMap<Integer,Bean>();
    
    Bean b=new Bean();
    
    
    
    
    
    @Override
    public Bean createAccount(Bean b) {
        // TODO Auto-generated method stub
         m.put(accountNumber, b);
    return m.get(accountNumber);
        }

    
  
    
    public int showbalance (int accountNumber) {
            // TODO Auto-generated method stub
        int sb=0;
        for(Bean b:m.values())
        {
        sb=(int)b.getCurrentBalance();
    }
        return sb;
}

    

    @Override
    public int deposit(Bean b,int deposit1) {
    	 {
    		// TODO Auto-generated method stub
    		b.setCurrBal(deposit1);
    		return (int) b.getCurrBal();
    	}
        
        // TODO Auto-generated method stub
        
        
    }

    @Override
    public int withdraw(Bean b,int withdraw) {
        // TODO Auto-generated method stub
    	b.setCurrBal(withdraw);
		return (int) b.getCurrBal();
	}
public boolean fundTransfer(Bean b,Bean a,int accountNumber4,int accountNumber5,int pin4,int amount) {
    	
    	boolean flag=false;	
		if((b.getAccountNumber()==accountNumber4) && (a.getPin()==pin4))
		{
			if((a.getAccountNumber()==accountNumber5))
			{
				if((a.getCurrBal()>amount))
				{
				int balc=0;
				int balc1=0;
				balc=b.getAccountNumber()-amount;
				balc1=a.getAccountNumber()+amount;
				b.setCurrBal(balc);
				a.setCurrBal(balc1);
				flag=true;
				}
			}
		
		}
		return flag;
		}
		
    

    
    public void printTransaction() {
        // TODO Auto-generated method stub
        
    }

    

    public boolean validAccountNumber(int accountNumber4, int pin4) {
        boolean flag=false;
        for(Bean b:m.values())
        {
            if( b.getAccountNumber()==accountNumber || b.getPin()==pin4)
            {
                flag= true;
                
            
            }
        // TODO Auto-generated method stub
    
        }
        return flag;
    }
    
    
    public boolean validAccountNumber(int accountNumber5) {
        boolean flag=false;
        for(Bean a:m.values())
        {
            if( a.getAccountNumber()==accountNumber )
            {
                flag= true;
                
            
            }
        // TODO Auto-generated method stub
    
        }
        return flag;
    }

    public boolean validateAmount(int withdraw) {
		boolean flag=false;
		for(Bean b:m.values())
		{
			if((b.getCurrBal()-withdraw)>500) 
			{
				flag=true;
			}
		
		
	}
	
	return flag;
}
    
  

    


    

//  @Override
//  public double deposit() {
//      // TODO Auto-generated method stub
//      int b;
//      
//      System.out.println("Enter account number");
//       Scanner sc=new Scanner(System.in);
//      b=sc.nextInt();
//      if(accountNum==b) {
//          
//           double depAmount=sc.nextInt();
//    this.balance=this.balance+depAmount;
//    System.out.println("Your deposited amount is "+this.balance);
//  
//  }
//      else {
//          System.out.println("Incorrect accountnumber");
//      }
//          
//      return 0;
//  }
//
//
//  
//  
//  @Override
//  public double withdraw() {
//      // TODO Auto-generated method stub
//      int b;
//      
//      System.out.println("enter account number");
//       Scanner sc=new Scanner(System.in);
//      b=sc.nextInt();
//      if(accountNum==b) {
//           System.out.println("Your withDraw amount is ");
//           double withDrawAmount=sc.nextInt();
//    this.balance=this.balance-withDrawAmount;
//    System.out.println("your withDraw amount is "+this.balance);
//  
//      return 0;
//  }
//      return withdraw;
//      
//  }
//
//  @Override
//  public double fundTransfer() {
//      // TODO Auto-generated method stub
//     int b;
//      
//      System.out.println("Enter account number");
//       Scanner sc=new Scanner(System.in);
//      b=sc.nextInt();
//      if(accountNum==b) {
//           System.out.println("Your fundTransfer amount is ");
//           double fundTransfer=sc.nextInt();
//    this.balance=this.balance-fundTransfer;
//    System.out.println("u r fundTransfer amount is "+this.balance);
//  
//      return 0;
//  }
//      return fundTransfer;
//      
//  
//  }
//
//  public void printTransaction() {
//      // TODO Auto-generated method stub
//      System.out.println(m.get(accountNum));
//      
//  }
    /*
    Set<Integer>keys=m.keySet();
    Iterator<Integer>it=keys.iterator();
    while(it.hasNext()) {
        Integer key=it.next();
    System.out.println(m.get(key));*/

}


    
