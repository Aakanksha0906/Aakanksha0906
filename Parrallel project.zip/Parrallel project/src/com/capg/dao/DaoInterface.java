


package com.capg.dao;

import com.capg.bean.Bean;

public interface DaoInterface {
    public Bean createAccount(Bean b);
    public int showbalance(int accountNumber);
    public int deposit(Bean b,int deposit);
    public int withdraw(Bean b,int withdraw);
    public boolean fundTransfer(Bean b, Bean a,int accountNumber4,int accountNumber5,int pin4,int amount);
    public boolean validAccountNumber(int accountNumber4 ,int pin4) ;
    public boolean validAccountNumber(int accountNumber5) ;
    

}

