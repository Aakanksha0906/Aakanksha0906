package com.capg.service;



import com.capg.bean.Bean;
import com.capg.dao.Dao;




public class Service  implements ServiceInt {
    
    Dao d=new Dao();
    double deposit,withdraw,fundTransfer;
    static double balance;
    

    @Override
    public Bean createAccount(Bean b) {
        // TODO Auto-generated method stub
        
        return d.createAccount(b);
        
    }
    public  boolean addBean(Bean b) {
        boolean flag=false;
        if(isValidName(b.getName()) && isValidMobNumber(b.getMobNumber()) && isValidCustomerId(b.getCustomerid()) && isValidaadharNumber(b.getAadhaarNumber()));
        flag=true;
        
        return flag;
        
    }
    public boolean isValidName(String name) {
        boolean flag=false;
        if(((name!=null) && name.matches("[A-Z][a-z]+"))) {
            flag= true;
        }else {
            System.out.println("Invalid Name");
            flag=false;
        }
        return flag;
        
    }
    public boolean isValidMobNumber(String mobNumber) {
        boolean flag=false;
        if(((mobNumber !=null) && mobNumber.matches("[4-9][0-9]{9}"))){
            flag=true;
        }else {
            System.out.println("Invalid MobileNumber");
        flag=false;
        }return flag;
        
            
        }
    public boolean isValidCustomerId(String customerid ) {
        boolean flag=false;
        if(((customerid !=null) && customerid.matches("[0-9][0-9]{6}"))) {
            flag= true;
        }else {
            System.out.println("Invalid CustomerId");
            flag=false;
        }return flag;
    }
    
        public boolean isValidaadharNumber(String aadharNumber) {
            boolean flag=false;
            if(((aadharNumber !=null) && aadharNumber.matches("[1-9][0-9]{9}"))) {
                flag=true;
            }else
                System.out.println("Invalid AadharNumber");
            
            return flag;
        }
        

    

    @Override
    public int showBalance(int accountNumber) {
        // TODO Auto-generated method stub
        return d.showbalance(accountNumber);
        

    }
    public boolean validAccountNumber(int accountNumber4,int pin4)
    {
    return  d.validAccountNumber(accountNumber4,pin4);
        // TODO Auto-generated method stub
        
    }
    public boolean validAccountNumber(int accountNumber5)
    {
    return  d.validAccountNumber(accountNumber5);
        // TODO Auto-generated method stub
    }
    
    
    public boolean validateAmount(int withdraw)
	{
		return d.validateAmount(withdraw);
	}


    @Override
    public int deposit(Bean b,int deposit) {
    	int deposit1=0;
		// TODO Auto-generated method stub
		if(deposit>=100)
		{
		 deposit1=(int) (b.getCurrentBalance()+deposit);
			
		}
		b.setCurrentBalance(deposit1);
			return d.deposit(b,deposit1);
		}
		
		

		

    

    @Override
   
    	public int withDraw(Bean b,int withdraw) {
    		// TODO Auto-generated method stub
    		if(b.getCurrentBalance()-withdraw>500)
    		{
    			withdraw=(int) (b.getCurrentBalance()-withdraw);
    			
    		// TODO Auto-generated method stub
    			
    		
    	
    		}
    	
    	return d.withdraw(b,withdraw);
    	}
        

    @Override
    public boolean fundTransfer(Bean b,Bean a,int accountNumber4,int accountNumber5,int pin4,int amount) {
    	
  
        return d.fundTransfer(b,a,accountNumber4,accountNumber5,pin4,amount);

    }
    
    @Override
    public void     printTransaction() {
        // TODO Auto-generated method stub
        d.  printTransaction();
        

    }
    
    


}