package com.capg.service;

import com.capg.bean.Bean;

public interface ServiceInt {
	

    public int showBalance(int accountNumber) ;

    public Bean createAccount(Bean b);

    public int deposit(Bean b,int deposit);

    public int withDraw(Bean b,int withdraw);

    public boolean fundTransfer(Bean b,Bean a,int accountNumber4,int accountNumber5,int pin4,int amount);
    
    public void printTransaction();

    public boolean validAccountNumber(int accountNumber4,int pin4) ;
    public boolean validAccountNumber(int accountNumber5) ;
    

}





