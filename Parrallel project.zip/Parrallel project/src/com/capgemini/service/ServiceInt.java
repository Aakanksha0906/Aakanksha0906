package com.capgemini.service;

import com.capgemini.entity.Bean;
import com.capgemini.exception.BeanNotFound;

public interface ServiceInt {
	

    public double showBalance(int accountNumber)throws BeanNotFound ;

    public void createAccount(Bean b) throws BeanNotFound;

    public double deposit(double deposit,int accountNumber) throws BeanNotFound;

    public double withdraw(int accountNumber, double withdraw) throws BeanNotFound;

    public double fundTransfer(int accountNumber4,int accountNumber5,int amount)throws BeanNotFound;
    
    

    public boolean validAccountNumber(int accountNumber5) throws BeanNotFound;

    public boolean validateAmount(double withdraw)throws BeanNotFound;

	 public String printTransaction(int accountNumber6) throws BeanNotFound;
    

}





