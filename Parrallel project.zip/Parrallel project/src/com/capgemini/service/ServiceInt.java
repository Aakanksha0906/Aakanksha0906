package com.capgemini.service;

import java.util.List;

import com.capgemini.entity.Bean;
import com.capgemini.entity.Transaction;
import com.capgemini.exception.BeanNotFound;

public interface ServiceInt {
	

    public double showBalance(int accountNumber)throws BeanNotFound ;

    public void createAccount(Bean b) throws BeanNotFound;

    public double deposit(double deposit,int accountNumber) throws BeanNotFound;

    public double withdraw(int accountNumber, double withdraw) throws BeanNotFound;

    public double fundTransfer(int accountNumber4,int accountNumber5,int amount)throws BeanNotFound;
    
    

    public boolean validAccountNumber(int accountNumber5) throws BeanNotFound;

    public boolean validateAmount(double withdraw)throws BeanNotFound;

	 public List<Transaction> printTransaction(int accountNumber6) throws BeanNotFound;
    

}





