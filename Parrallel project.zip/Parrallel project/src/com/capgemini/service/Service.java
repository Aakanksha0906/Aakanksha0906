package com.capgemini.service;



import com.capgemini.dao.Dao;
import com.capgemini.entity.Bean;
import com.capgemini.exception.BeanNotFound;




public class Service  implements ServiceInt {
    
    Dao d=new Dao();
    double deposit,withdraw,fundTransfer;
    static double balance;
    

    @Override
    public void createAccount(Bean b) throws BeanNotFound {
        // TODO Auto-generated method stub
        
        d.createAccount(b);
        
    }
    
    
    
    @Override
    public double showBalance(int accountNumber)throws BeanNotFound {
        // TODO Auto-generated method stub
        return d.showbalance(accountNumber);
        

    }
    
    
    
    @Override
    public double deposit(double deposit,int accountNumber) throws BeanNotFound{
    	
		// TODO Auto-generated method stub
		
			return d.deposit(deposit,accountNumber);
		}
		
    
    

    @Override
   
    public double withdraw(int accountNumber, double withdraw) throws BeanNotFound{
    		// TODO Auto-generated method stub
    		
    			
    		return d.withdraw(accountNumber,withdraw);
    	}
        

    @Override
    public double fundTransfer(int accountNumber4,int accountNumber5,int amount) throws BeanNotFound{
    	
  
        return d.fundTransfer(accountNumber4,accountNumber5,amount);

    }
    
    
    
    
    
    @Override
    public void     printTransaction() throws BeanNotFound{
        // TODO Auto-generated method stub
        d.  printTransaction();
        

    }
    
    
    
    public  boolean addBean(Bean b)throws BeanNotFound {
        boolean flag=false;
        if(isValidName(b.getName()) && isValidMobNumber(b.getMobNumber()) && isValidCustomerId(b.getCustomerid()) && isValidaadharNumber(b.getAadhaarNumber()));
        flag=true;
        
        return flag;
        
    }
    public boolean isValidName(String name) throws BeanNotFound{
        boolean flag=false;
        if(((name!=null) && name.matches("[A-Z][a-z]+"))) {
            flag= true;
        }else {
            System.out.println("Invalid Name");
            flag=false;
        }
        return flag;
        
    }
    public boolean isValidMobNumber(String mobNumber)throws BeanNotFound {
        boolean flag=false;
        if(((mobNumber !=null) && mobNumber.matches("[4-9][0-9]{9}"))){
            flag=true;
        }else {
            System.out.println("Invalid MobileNumber");
        flag=false;
        }return flag;
        
            
        }
    public boolean isValidCustomerId(String customerid )throws BeanNotFound {
        boolean flag=false;
        if(((customerid !=null) && customerid.matches("[0-9][0-9]{6}"))) {
            flag= true;
        }else {
            System.out.println("Invalid CustomerId");
            flag=false;
        }return flag;
    }
    
        public boolean isValidaadharNumber(String aadharNumber)throws BeanNotFound {
            boolean flag=false;
            if(((aadharNumber !=null) && aadharNumber.matches("[1-9][0-9]{9}"))) {
                flag=true;
            }else
                System.out.println("Invalid AadharNumber");
            
            return flag;
        }
        

    

    
   
    public boolean validAccountNumber(int accountNumber5)throws BeanNotFound
    {
    return  d.validAccountNumber(accountNumber5);
        // TODO Auto-generated method stub
    }
    
    
    public boolean validateAmount(double withdraw)throws BeanNotFound
	{
		return d.validateAmount(withdraw);
	}


   
		

		

    


   
    
   


}