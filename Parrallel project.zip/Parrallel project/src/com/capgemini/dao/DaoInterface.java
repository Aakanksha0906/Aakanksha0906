


package com.capgemini.dao;

import com.capgemini.entity.Bean;
import com.capgemini.exception.BeanNotFound;

public interface DaoInterface {
    public boolean createAccount(Bean b) throws BeanNotFound;
    public double showbalance(int accountNumber) throws BeanNotFound;
    public double deposit(double deposit,int accountNumber) throws BeanNotFound;
    public double withdraw(int accountNumber,double withdraw) throws BeanNotFound;
    public double fundTransfer(int accountNumber4,int accountNumber5,int amount)throws BeanNotFound;
    public boolean validAccountNumber(int accountNumber5) throws BeanNotFound;
    public String printTransaction(int accountNumber6) throws BeanNotFound ;
    

}

