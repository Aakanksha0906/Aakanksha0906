package com.capgemini.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.Query;

import com.capgemini.entity.Bean;
import com.capgemini.entity.Transaction;
import com.capgemini.exception.BeanNotFound;
import com.capgemini.utility.BankUtil;


public class Dao implements DaoInterface{
	
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("Parrallel project");
	EntityManager entityManager = factory.createEntityManager();
    static double balance;
    double deposit,withdraw,fundTransfer;
    
 
  Scanner sc=new Scanner(System.in);
   
    
   
    @Override
    public boolean createAccount(Bean b) throws BeanNotFound {

		try{
			
			entityManager=BankUtil.getEntityManager();
			 entityManager.getTransaction().begin();
			  b.setAccountNumber(0);
			  entityManager.persist(b);
			//transaction.commit
			  entityManager.getTransaction().commit();
			  return true;
	    	}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new BeanNotFound(e.getMessage());
		}finally {
			entityManager.close();
		}
		
	}



    
  
    
    public double showbalance (int accountNumber) throws BeanNotFound{
            try{
            	
            	Bean b=entityManager.find(Bean.class,accountNumber);
            	return b.getCurrentBalance();
            	}catch(PersistenceException e){
            		e.printStackTrace();
            		throw new BeanNotFound(e.getMessage());
            	}finally
            	{
            		entityManager.close();
            	}
            		
    }

    

    @Override
    public double deposit(double deposit,int accountNumber) throws BeanNotFound{
    	 {
    		 
    		 double deposit1=0;
    		// TODO Auto-generated method stub
    		 try{
    			 
    			 Bean b=entityManager.find(Bean.class,accountNumber);
    			 double temp = b.getCurrentBalance();
 				 temp = temp+deposit;
 				 b.setCurrentBalance(temp);
 				 entityManager.getTransaction().begin();
    			 entityManager.merge(b);
    			 Transaction t=new Transaction();
    			 t.setType("deposit");
    			 t.setAmount(deposit);
    			 t.setBean(b);
    			 entityManager.persist(t);
    	   	   	 entityManager.getTransaction().commit();
    			 deposit1=b.getCurrentBalance();
    			 return deposit1;
    				
                  }catch(PersistenceException e){
         	       	e.printStackTrace();
         	    	throw new BeanNotFound(e.getMessage());
             	}
         		
         	}
    		
        
        
    }
    
    

    @Override
    public double withdraw(int accountNumber,double withdraw)throws BeanNotFound {
    	double withdraw1=0;
    	try{
			 entityManager=BankUtil.getEntityManager();
			 entityManager.getTransaction().begin();
			 Bean b=entityManager.find(Bean.class,accountNumber);
				double temp = b.getCurrentBalance();//storing actual balance in temporary variable
				temp = temp-withdraw;
				b.setCurrentBalance(temp);//set the amount which we had withdrawn in object b
				entityManager.merge(b);
				 Transaction t=new Transaction();
    			 t.setType("withdraw");
    			 t.setAmount(withdraw);
    			 t.setBean(b);
    			entityManager.persist(t);
				entityManager.getTransaction().commit();
				withdraw1=b.getCurrentBalance();
				return withdraw1;
				
             }catch(PersistenceException e){
    	       	e.printStackTrace();
    	    	throw new BeanNotFound(e.getMessage());
        	}
    		
    }
public double fundTransfer(int accountNumber4,int accountNumber5,int amount)throws BeanNotFound {
    	
    	
		withdraw(accountNumber4,amount);
		
		double d=deposit(amount,accountNumber5);
		if(d>0)
		{
			return d;
		}else
		return -1;
		
		
		}
		
    

    
    public String printTransaction(int accountNumber6) throws BeanNotFound {
        // TODO Auto-generated method stub
    	try {
    		entityManager=BankUtil.getEntityManager();
    		 Bean b=entityManager.find(Bean.class,accountNumber6);
    		 return b.getStatus();
    	}catch(PersistenceException e) {
    		e.printStackTrace();
    		throw new BeanNotFound(e.getMessage());
    	
    	}
        
    }
    public List<Transaction> printTransactions(int accountNumber) throws BeanNotFound
	{
		
    	
    	entityManager.getTransaction().begin();
		List<Transaction> pt = new ArrayList<Transaction>();
		Query query = entityManager.createNativeQuery("select * from transactions where accountNumber = ?",Transaction.class);
		query.setParameter(1, accountNumber);
		pt = query.getResultList();
		
			
		return pt;
		
	} 

    

   public boolean validAccountNumber(int accountNumber4)throws BeanNotFound {
      /*boolean flag=false;
        for(Bean b:m.values())
        {
           if( b.getAccountNumber()==accountNumber4 && b.getPin()==pin4)
            {
            
                flag= true;
                
            
            }
    
       }*/
      return true;
  }
        
    

    public boolean validateAmount(double withdraw)throws BeanNotFound {
		boolean flag=false;
		
//		for(Bean b:m.values())
//		{
//			System.out.println(b.getCurrentBalance());
//			if((b.getCurrentBalance()-withdraw)>500) 
//			{
//				
//				flag=true;
//			}
		
		
	//}
	
	return flag;
}






}

    


    
