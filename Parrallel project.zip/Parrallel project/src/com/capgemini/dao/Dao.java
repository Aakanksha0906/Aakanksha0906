package com.capgemini.dao;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.capgemini.entity.Bean;
import com.capgemini.exception.BeanNotFound;
import com.capgemini.utility.BankUtil;


public class Dao implements DaoInterface{
	private EntityManager entityManager;
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("Parrallel project");
	EntityManager em = factory.createEntityManager();
    static double balance;
    double deposit,withdraw,fundTransfer;
    
 
  Scanner sc=new Scanner(System.in);
   
    
   
    @Override
    public void createAccount(Bean b) throws BeanNotFound {

		try{
			
			entityManager=BankUtil.getEntityManager();
			 entityManager.getTransaction().begin();
			  b.setAccountNumber(0);
			  entityManager.persist(b);
			//transaction.commit
			  entityManager.getTransaction().commit();			
	    	}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new BeanNotFound(e.getMessage());
		}finally {
			entityManager.close();
		}
		
	}



    
  
    
    public double showbalance (int accountNumber) throws BeanNotFound{
            try{
            	entityManager=BankUtil.getEntityManager();
            	Bean b=entityManager.find(Bean.class,accountNumber);
            	return b.getCurrentBalance();
            	}catch(PersistenceException e){
            		e.printStackTrace();
            		throw new BeanNotFound(e.getMessage());
            	}finally
            	{
            		entityManager.close();
            	}
            		
    }

    

    @Override
    public double deposit(double deposit,int accountNumber) throws BeanNotFound{
    	 {
    		 
    		 double deposit1=0;
    		// TODO Auto-generated method stub
    		 try{
    			 entityManager=BankUtil.getEntityManager();
    			 entityManager.getTransaction().begin();
    			 Bean b=entityManager.find(Bean.class,accountNumber);
    				double temp = b.getCurrentBalance();
    				temp = temp+deposit;
    				b.setCurrentBalance(temp);
    				entityManager.merge(b);
    				entityManager.getTransaction().commit();
    				deposit1=b.getCurrentBalance();
    				return deposit1;
    				
                  }catch(PersistenceException e){
         	       	e.printStackTrace();
         	    	throw new BeanNotFound(e.getMessage());
             	}finally
         	{
         		entityManager.close();
         	}
         		
         	}
    		
        
        
    }
    
    

    @Override
    public double withdraw(int accountNumber,double withdraw)throws BeanNotFound {
    	double withdraw1=0;
    	try{
			 entityManager=BankUtil.getEntityManager();
			 entityManager.getTransaction().begin();
			 Bean b=entityManager.find(Bean.class,accountNumber);
				double temp = b.getCurrentBalance();//storing actual balance in temporary variable
				temp = temp-withdraw;
				b.setCurrentBalance(temp);//set the amount which we had withdrawn in object b
				entityManager.merge(b);
				entityManager.getTransaction().commit();
				withdraw1=b.getCurrentBalance();
				return withdraw1;
				
             }catch(PersistenceException e){
    	       	e.printStackTrace();
    	    	throw new BeanNotFound(e.getMessage());
        	}finally
    	{
    		entityManager.close();
    	}
    		
    }
public double fundTransfer(int accountNumber4,int accountNumber5,int amount)throws BeanNotFound {
    	
    	
		withdraw(accountNumber4,amount);
		
		double d=deposit(amount,accountNumber5);
		if(d>0)
		{
			return d;
		}else
		return -1;
		
		
		}
		
    

    
    public void printTransaction() {
        // TODO Auto-generated method stub
        
    }

    

   public boolean validAccountNumber(int accountNumber4)throws BeanNotFound {
      /*boolean flag=false;
        for(Bean b:m.values())
        {
           if( b.getAccountNumber()==accountNumber4 && b.getPin()==pin4)
            {
            
                flag= true;
                
            
            }
    
       }*/
      return true;
  }
        
    

    public boolean validateAmount(double withdraw)throws BeanNotFound {
		boolean flag=false;
		
//		for(Bean b:m.values())
//		{
//			System.out.println(b.getCurrentBalance());
//			if((b.getCurrentBalance()-withdraw)>500) 
//			{
//				
//				flag=true;
//			}
		
		
	//}
	
	return flag;
}






}

    


    
