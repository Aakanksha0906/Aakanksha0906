package com.capgemini.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.persistence.ManyToOne;
import com.capgemini.entity.Transaction;

@Table(name="bank_details")
@Entity
public class Bean {
	 @Id
	  @GeneratedValue(strategy=GenerationType.IDENTITY)
	  int accountNumber;
	  
	 
	
	  @NotNull
  private String name;
  private String mobNumber,aadhaarNumber;
  private String customerid ;
  private double CurrentBalance=0;
  
  @OneToMany(mappedBy="bean",cascade=CascadeType.ALL)
  List<Transaction> t = new ArrayList<Transaction>();
  


public String getStatus() {
	return Status;
}





public void setStatus(String status) {
	Status = status;
}





private String Status; 
 

    
     public double getCurrentBalance() {
         return CurrentBalance;
     }
    
   

    public void setCurrentBalance(double currentBalance) {
        CurrentBalance = currentBalance;
    }


   
    
    public String getCustomerid() {
        return customerid;
    }


    public void setCustomerid(String customerid) {
        this.customerid = customerid;
    }


    public int getAccountNumber() {
        return accountNumber;
    }


    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }


    public void setAadhaarNumber(String aadhaarNumber) {
        this.aadhaarNumber = aadhaarNumber;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    

    public  String getMobNumber() {
        return mobNumber;
    }
    public void setMobNumber(String mobNumber) {
        this.mobNumber = mobNumber;
    }
    public String getAadhaarNumber() {
        return aadhaarNumber;
    }
    
    
    @Override
	public String toString() {
		return "Bean [accountNumber=" + accountNumber + ", name=" + name + ", mobNumber=" + mobNumber
				+ ", aadhaarNumber=" + aadhaarNumber + ", customerid=" + customerid + ", CurrentBalance="
				+ CurrentBalance + ", Status=" + Status + "]";
	}


    
    
    }
    
    
    
    