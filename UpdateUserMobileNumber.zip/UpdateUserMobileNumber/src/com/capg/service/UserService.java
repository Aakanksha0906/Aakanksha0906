package com.capg.service;

import com.capg.bean.User;

public interface UserService {
	
	public User addUser(User user) ;
	public User displayUser(int userid);
	public User update(int userid, String mobilenumber); 
	}


