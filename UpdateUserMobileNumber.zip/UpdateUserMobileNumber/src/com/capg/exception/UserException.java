package com.capg.exception;

public class UserException extends Exception{

}
