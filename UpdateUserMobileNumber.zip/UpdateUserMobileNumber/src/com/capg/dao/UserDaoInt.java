package com.capg.dao;

import com.capg.bean.User;

public interface UserDaoInt {
	public Integer addUser(User user) ;
	
	public User displayUser(int userid) ;
	public String update(int userid);
		
	
	}
	
		
	



