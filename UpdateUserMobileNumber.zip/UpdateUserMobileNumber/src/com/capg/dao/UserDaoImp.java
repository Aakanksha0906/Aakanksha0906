package com.capg.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capg.bean.User;


public class UserDaoImp {
	
	
	 Scanner sc=new Scanner(System.in);
	    Map <Integer,User> m=new HashMap<Integer,User>();
	    User user=new User();

	 
	    public User addUser(User user)  {
	        // TODO Auto-generated method stub
	         m.put(user.getUserid(), user);
	        
			return  m.get(user.getUserid());
	        }
	    
	    

	
       public User displayUser(int userid) {
		User us=null;
		
	
		for(User m:m.values())
		{
			if(m.getUserid()==userid)
				us=m;
		}
			
			return us;
		}
		
		
			
			
			public User update(int userid, String mobilenumber) {
				User us=null;
				for(User m:m.values())
				{
				if(m.getUserid()==userid)
				{
					String Mobilenumber=m.getMobilenumber();
					
				}
				
				
				return user;
				
				
			
			
		}
				return us;


}
}
