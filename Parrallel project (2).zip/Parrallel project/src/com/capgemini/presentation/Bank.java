 package com.capgemini.presentation;
import java.util.Scanner;

import com.capgemini.dao.Dao;
import com.capgemini.entity.Bean;
import com.capgemini.exception.BeanNotFound;
import com.capgemini.service.Service;

public class Bank {
    static Service s=new Service();
    static Bean b=new Bean();
    Dao d=new Dao();
    
    
    
    public static void main(String[]args) throws BeanNotFound
    {       
        
        
        String name;
        String mobNumber;
        String aadhaarNumber;
        int n;String customerid;

        Scanner sw =new Scanner(System.in);
        
        while(true) {

        System.out.println(" 1.Create accountNumber\n 2.ShowBalance\n 3.Deposited\n 4.WithDraw\n 5.FundTransfer\n 6.Print Transactions");
        System.out.println(" Enter u r choice");
        
        n=sw.nextInt();
        boolean z;
        switch(n){
        
            case 1 :
            
            do {
                        
                    System.out.println("Enter the Name");
                    name=sw.next();
                    z=s.isValidName(name);
                    }while(z==false);
                    
                    
                    do {
                        
                    System.out.println("Enter the Aadhar");
                    aadhaarNumber=sw.next();
                    z=s.isValidaadharNumber(aadhaarNumber);
                    }while(z==false);
                    
                    
                    do {
                        
                    System.out.println("Enter the MobNumber");
                    mobNumber=sw.next();
                    z=s.isValidMobNumber(mobNumber);
                    }while(z==false) ;
                    
                    
                    do {
                        
                    System.out.println("Enter the CustomerId");
                    customerid=sw.next();
                    z=s.isValidCustomerId(customerid);
                    }while(z==false);
                    
                    
                    
                    b.setName(name);
                    b.setAadhaarNumber(aadhaarNumber);
                    b.setMobNumber(mobNumber);
                    b.setCustomerid(customerid);
                   // b.getAccountNumber();
                    b.getCustomerid();
                    int  accountNumber =(int)((Math.random()*900000)+100000);
                   
                    b.setAccountNumber(accountNumber);
                    boolean isValid=s.addBean(b);
                    if(isValid) {
                        s.createAccount(b);
                        
                    }else {
                        System.out.println("Not Recorded");
                    }
                    
                    System.out.println(b.getAccountNumber());
                    
                    
                    break;
            case 2 :System.out.println("show balance");
                    System.out.println("enter the account number");
                    int accountNumber1 = sw.nextInt();
                   
            
                    boolean valid= s.validAccountNumber( accountNumber1);
                    if (valid) {
                    	
                     double balanceAmount = s.showBalance(accountNumber1);
                        System.out.println("Balance is" + balanceAmount);
                    }else
                        System.out.println("enter valid details");
                        
                        break;
            
            case 3:
                System.out.println("deposit");
                System.out.println("enter the account number");
                int accountNumber2 = sw.nextInt();
                
                
                boolean valid1 = s.validAccountNumber( accountNumber2);
                if (valid1) {
                    System.out.println("enter the amount to be deposit");
                    double deposit = sw.nextDouble();
                    double deposit1 = s.deposit(deposit,accountNumber2);
                    b.setCurrentBalance(deposit1);
                    System.out.println("deposited successfully");
                    System.out.println("the deposited amount is" + deposit1);
                    System.out.println("Balance is" + deposit1);


                } else
                    System.out.println("Enter the valid amount");

                break;
                        
            case 4:     
                    System.out.println(" withdraw ");
                    System.out.println("enter the account number");                                            
                    int accountNumber3 = sw.nextInt();                                                              
                                                                                       
                    boolean valid2= s.validAccountNumber( accountNumber3);                             
                    if (valid2) {                                                                               
                    	System.out.println("enter the amount to be withdraw");                                 
                    	double withdraw = sw.nextInt();   
                    	double withdraw1=s.withdraw(accountNumber3, withdraw);
                    	b.setCurrentBalance(withdraw1);
                    	                      
                    		System.out.println("withdraw successful");                                         
                    		System.out.println("withdrawn amount is"+withdraw1);                                
                    		System.out.println(" Remaining balance is :" + withdraw1);                    
                    	} else                                                                                 
                    		System.out.println("the amount should not be more than available amount");         
                                                          
                                                                                                               
                    break;                                                                                     
                                                                                                               
                  
            case 5:
                    System.out.println("Fund transfer");
                    System.out.println("enter the account no of transferer");
                    int accountnumber4=sw.nextInt();
                    System.out.println("enter the pin");                                                       
                    int pin4 = sw.nextInt();                                                                    
                    boolean valid3= s.validAccountNumber(accountnumber4);
                    System.out.println(valid3);
                    if (valid3) {  
                    	System.out.println("enter the account no of receiver");
                        int accountnumber5=sw.nextInt();
                     
                        boolean valid4= s.validAccountNumber(accountnumber5); 
                        
                        if (valid4) {
                        	System.out.println("enter the amount to be withdraw");                                 
                        	int amount = sw.nextInt(); 
                        	   Bean a= new Bean();
                        	boolean fund= s.fundTransfer(b,a,accountnumber4,accountnumber5,pin4,amount);
                        	     if(fund){
   							 System.out.println("BALANCE IN YOUR ACCOUNT AFTER TRANSFER IS"+a.getCurrentBalance());
   								System.out.println("BALANCE IN OTHER ACCOUNT IS"+b.getCurrentBalance());
   						          }else {
   							          try
   							          {
   									throw new BeanNotFound("SORRRY TRANSACTION FAILED!!!!");
   									
   						               	}
   							        catch(BeanNotFound e)
   							          {
   							      	System.out.println(e.getMessage());
   							          }
   							
   						              }
                                  }
                        else
   						{
   							
   							try
   							{
   									throw new BeanNotFound("ENTER THE VALID account number to TRANSFER");
   							}
   							catch(BeanNotFound e)
   							{
   								System.out.println(e.getMessage());
   					
                        }
   						
   						}
                    }
                  
   						else
   						{
   							
   							try
   							{
   									throw new BeanNotFound("ENTER THE VALID DETAILS TO TRANSFER");
   							}
   							catch(BeanNotFound e)
   							{
   								System.out.println(e.getMessage());
   					
                        }
   						}
                    
                    
        
                   
                    break;
            case 6:
                    System.out.println("Transaction");
                    s.printTransaction();
                    break;
            case 7: System.exit(0);
            default: 
                    System.out.println("wrong choice");
                    break;
        }
        
            }
        }

}
