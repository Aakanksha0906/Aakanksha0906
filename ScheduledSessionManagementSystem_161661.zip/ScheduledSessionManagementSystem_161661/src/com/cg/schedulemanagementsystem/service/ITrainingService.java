package com.cg.schedulemanagementsystem.service;

import java.util.List;

import com.cg.schedulemanagementsystem.dto.Client;

public interface ITrainingService {

	public List<Client> getAllDetails();

}
