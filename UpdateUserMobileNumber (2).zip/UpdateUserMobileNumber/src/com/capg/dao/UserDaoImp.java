package com.capg.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import com.capg.bean.User;


public class UserDaoImp {
	
	
	 Scanner sc=new Scanner(System.in);
	    Map <Integer,User> m=new HashMap<Integer,User>();
	    User user=new User(); //creating bean object it should be same

	 
	    public Integer addUser(User user)  {// bean ,bean obj
	        // TODO Auto-generated method stub
	    	
	         m.put(user.getUserid(), user);  //beanobj.getid,beanobj
	         return user.getUserid();
	        }
	    
	    
	    
	    
	    
	       public Boolean validUser(int userid) {
	   		Boolean us=false;                  //creating the obj
	   		
	   	
	   		for(User user:m.values())  //bean beanobj:m values
	   		{
	   			if(user.getUserid()==userid)  // bean.getid()=id
	   				us=true;
	   		}
	   			
	   			return us;                         //return the obj
	   		}
	   		

	
	       
	       
	        
       public User displayUser(int userid) {
		User us=null;
		
	
		for(User user:m.values())
		{
			if(user.getUserid()==userid)
				us=user;
		}
			
			return us;
		}
		
		
			
			
			public String update(int userid, String mobilenumber) {
				User us=null;
				for(User user:m.values())
				{
				if(user.getUserid()==userid)
				{
					user.setMobilenumber(mobilenumber);
					us=user;
					
				}
				
			
			
			
		}
				return us.getMobilenumber();


}
}