package com.capg.realestate.exception;

public class OwnerNotFound extends Exception {
	public OwnerNotFound(String a)
	{
		super(a);
	}

}
