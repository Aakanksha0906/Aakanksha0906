package com.capg.realestate.service;

import com.capg.realestate.beans.User;

public interface IUserService {
	
	public boolean addUser(User u);
	public User displayUser(int flatId);
	public boolean validOwnerId(int ownerId);
}
