package com.capg.realestate.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capg.realestate.dao.UserDAOImp;
import com.capg.realestate.service.UserServiceImp;

class RealestateTest {
UserDAOImp se=new UserDAOImp();
	@Test
	void testAddUser() {
		
	
	
		boolean a=se.validOwnerId(1);
	
		
		assertEquals(true,a);
	}

}
